Custom Twitter Bootstrap Button Generator with FamFamFam Icons

1. Download and link Twitter Bootstrap CSS file to your website from http://twitter.github.com/bootstrap/
   example: <link rel="stylesheet" type="text/css" href="path_to_file/css/bootstrap.min.css" />

2. Link "fam-icons.css" file to your website
   example: <link rel="stylesheet" type="text/css" href="path_to_file/css/fam-icons.css" />

3. (optional) Change sprite img path in CSS file if needed. Default path is "../img/famfamfam-icons.png"

4. Now you can use 1000 FamFamFam icons together with Twitter Bootstrap with class "fam-xxx"

5. Don't be shy and spread the word 


Now you can use "fam-xxx" class to use FamFamFam icons (Twitter Bootstrap by default use "icon-xxx" class to insert an icon).

List of FamFamFam icon classes you can get from "fam-icons.css" or from our button generator at: 
http://www.plugolabs.com/custom-twitter-bootstrap-button-generator-with-famfamfam-icons/

-----------------------------------------------------------------

FamFamFam icons Licence: http://www.famfamfam.com/lab/icons/silk/

-----------------------------------------------------------------

www.plugolabs.com
Follow us on Twitter: @plugolabs